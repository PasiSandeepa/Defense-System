/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author kavin
 */
public interface DefenseInterface {
    public void clearArea();
    public void enableButtons(int value);
    public void appendMessage(String text);
    
}
